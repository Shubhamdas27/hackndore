const mongoose = require('mongoose');

const workshopSchema = new mongoose.Schema({
  name: String,
  description: String,
  schedule: [{
    task: String,
    startTime: Date,
    endTime: Date,
    status: { type: String, enum: ['pending', 'ongoing', 'completed'] }
  }],
  resources: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Resource' }]
});

module.exports = mongoose.model('Workshop', workshopSchema);


// const mongoose = require('mongoose');
// //const Workshop = require('./models/Workshop'); // Ensure this path is correct

// const workshopSchema = new mongoose.Schema({
//   name: String,
//   description: String,
//   schedule: [{
//     task: String,
//     startTime: Date,
//     endTime: Date,
//     status: { type: String, enum: ['pending', 'ongoing', 'completed'] }
//   }],
//   resources: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Resource' }]
// });

// module.exports = mongoose.model('Workshop', workshopSchema);
