// models/Employee.js
const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  name: String,
  role: String,
  workingHours: Number,
  performance: String,
  workOrders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' }],
  attendance: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Attendance' }]
});

module.exports = mongoose.model('Employee', employeeSchema);
