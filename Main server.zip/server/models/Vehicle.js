const mongoose = require('mongoose');

const vehicleSchema = new mongoose.Schema({
  type: String,
  availability: Boolean,
  fuelConsumption: Number,
  schedule: [{
    workshop: { type: mongoose.Schema.Types.ObjectId, ref: 'Workshop' },
    startTime: Date,
    endTime: Date
  }]
});

module.exports = mongoose.model('Vehicle', vehicleSchema);
