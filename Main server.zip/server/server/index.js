const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const Workshop = require('./models/Workshop');
const Vehicle = require('./models/Vehicle');
const WorkOrder = require('./models/WorkOrder');
const Employee = require('./models/Employee'); 

const app = express();
const port = 3000;
app.use(bodyParser.json());

console.log('Hello World!');

mongoose.connect('mongodb://localhost:27017/workshopManagement', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB');
}).catch(err => {
  console.log('Error connecting to MongoDB', err);
});


// Workshop Routes
app.all('/workshops', async (req, res) => {
  const workshop = new Workshop(req.body);
  await workshop.save();
  res.send(workshop);
});

app.get('/workshops', async (req, res) => {
  const workshops = await Workshop.find();
  res.send(workshops);
});

// Vehicle Routes
app.post('/vehicles', async (req, res) => {
  const vehicle = new Vehicle(req.body);
  await vehicle.save();
  res.send(vehicle);
});

app.get('/vehicles', async (req, res) => {
  const vehicles = await Vehicle.find();
  res.send(vehicles);
});

// WorkOrder Routes
app.post('/workorders', async (req, res) => {
  const workOrder = new WorkOrder(req.body);
  await workOrder.save();
  res.send(workOrder);
});

app.get('/workorders', async (req, res) => {
  const workOrders = await WorkOrder.find();
  res.send(workOrders);
});

// Employee Routes
app.post('/employees', async (req, res) => {
  const employee = new Employee(req.body);
  await employee.save();
  res.send(employee);
});

app.get('/employees', async (req, res) => {
  const employees = await Employee.find();
  res.send(employees);
});




app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
