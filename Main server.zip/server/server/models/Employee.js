// models/Employee.js
const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
  name: String,
  role: String,
  workingHours: Number,
  performance: String,
  workOrders: [{ type: mongoose.Schema.Types.ObjectId, ref: 'WorkOrder' }],
  isAvailable: Boolean
});

module.exports = mongoose.model('Employee', employeeSchema);
