const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');

// Import your models
const Attendance = require('./models/Attendance');
const Employee = require('./models/Employee'); // Ensure this model exists
const Workshop = require('./models/Workshop'); // Import the Workshop model

const app = express();
const PORT = 3000;

app.use(bodyParser.json());

// Route for creating an Attendance record
app.all('/attendance', async (req, res) => {
  try {
    const { employee, date, status, checkIn, checkOut } = req.body;
    const attendance = new Attendance({ employee, date, status, checkIn, checkOut });
    await attendance.save();
    res.status(201).json(attendance);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Route for creating a Workshop record
app.all('/Vehicle', async (req, res) => {
  try {
    const { name, description, schedule, resources } = req.body;
    const workshop = new Workshop({ name, description, schedule, resources });
    await workshop.save();
    res.status(201).json(workshop);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Route for getting all Workshops
app.all('/workshops', async (req, res) => {
  try {
    const workshops = await Workshop.find();
    res.status(200).json(workshops);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Start the server
mongoose.connect('mongodb://localhost:27017/test_database', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  })
  .catch(err => console.error('Failed to connect to MongoDB:', err));

module.exports = app;




// // index.js
// const express = require('express');
// const mongoose = require('mongoose');
// const bodyParser = require('body-parser');

// const Attendance = require('./models/Attendance');
// const Employee = require('./models/Employee'); // Ensure this model exists
// const Workshop = require('./models/Workshop');
// const app = express();
// const PORT = 3000;

// app.use(bodyParser.json());

// // Example route for creating an Attendance record
// app.post('/attendance', async (req, res) => {
//   try {
//     const { employee, date, status, checkIn, checkOut } = req.body;
//     const attendance = new Attendance({ employee, date, status, checkIn, checkOut });
//     await attendance.save();
//     res.status(201).json(attendance);
//   } catch (err) {
//     res.status(400).json({ error: err.message });
//   }
// });

// // Start the server
// mongoose.connect('mongodb://localhost:27017/test_database', { useNewUrlParser: true, useUnifiedTopology: true })
//   .then(() => {
//     app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
//   })
//   .catch(err => console.error('Failed to connect to MongoDB:', err));

// module.exports = app;
