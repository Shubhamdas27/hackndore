var mongoose = require('mongoose');
var chai = require('chai');
var Employee = require('../models/Employee');

var expect = chai.expect;

// Replace with your MongoDB URI
var mongoURI = 'mongodb://localhost:27017/test_database';

describe('Employee Model Test', function() {
    // Before running the tests, connect to the database
    before(function(done) {
        mongoose.connect(mongoURI, { useNewUrlParser: true, useUnifiedTopology: true })
            .then(function() { done(); })
            .catch(function(err) { done(err); });
    });

    // Clear the database before each test
    beforeEach(function(done) {
        mongoose.connection.db.dropDatabase()
            .then(function() { done(); })
            .catch(function(err) { done(err); });
    });

    // After all tests, disconnect from the database
    after(function(done) {
        mongoose.connection.close()
            .then(function() { done(); })
            .catch(function(err) { done(err); });
    });

    it('should create & save an employee successfully', function(done) {
        var employeeData = {
            name: 'John Doe',
            role: 'Engineer',
            workingHours: 40,
            performance: 'Good',
            workOrders: [],
            isAvailable: true
        };
        var employee = new Employee(employeeData);
        employee.save(function(err, savedEmployee) {
            if (err) {
                done(err);
            } else {
                expect(savedEmployee.name).to.equal('John Doe');
                expect(savedEmployee.role).to.equal('Engineer');
                expect(savedEmployee.workingHours).to.equal(40);
                expect(savedEmployee.performance).to.equal('Good');
                expect(savedEmployee.workOrders).to.be.an('array').that.is.empty;
                expect(savedEmployee.isAvailable).to.be.true;
                done();
            }
        });
    });

    it('should not save an employee without a name', function(done) {
        var employeeData = {
            role: 'Engineer',
            workingHours: 40,
            performance: 'Good',
            workOrders: [],
            isAvailable: true
        };
        var employee = new Employee(employeeData);
        employee.save(function(err) {
            expect(err).to.exist;
            expect(err.errors.name).to.exist;
            done();
        });
    });

    it('should update an employee\'s working hours', function(done) {
        var employeeData = {
            name: 'John Doe',
            role: 'Engineer',
            workingHours: 40,
            performance: 'Good',
            workOrders: [],
            isAvailable: true
        };
        var employee = new Employee(employeeData);
        employee.save(function(err, savedEmployee) {
            if (err) {
                done(err);
            } else {
                savedEmployee.workingHours = 45;
                savedEmployee.save(function(err, updatedEmployee) {
                    if (err) {
                        done(err);
                    } else {
                        expect(updatedEmployee.workingHours).to.equal(45);
                        done();
                    }
                });
            }
        });
    });

    it('should delete an employee', function(done) {
        var employeeData = {
            name: 'John Doe',
            role: 'Engineer',
            workingHours: 40,
            performance: 'Good',
            workOrders: [],
            isAvailable: true
        };
        var employee = new Employee(employeeData);
        employee.save(function(err, savedEmployee) {
            if (err) {
                done(err);
            } else {
                Employee.findByIdAndDelete(savedEmployee._id, function(err, deletedEmployee) {
                    if (err) {
                        done(err);
                    } else {
                        expect(deletedEmployee).to.not.be.null;
                        done();
                    }
                });
            }
        });
    });

    it('should retrieve an employee by name', function(done) {
        var employeeData = {
            name: 'John Doe',
            role: 'Engineer',
            workingHours: 40,
            performance: 'Good',
            workOrders: [],
            isAvailable: true
        };
        var employee = new Employee(employeeData);
        employee.save(function(err, savedEmployee) {
            if (err) {
                done(err);
            } else {
                Employee.findOne({ name: 'John Doe' }, function(err, foundEmployee) {
                    if (err) {
                        done(err);
                    } else {
                        expect(foundEmployee).to.not.be.null;
                        expect(foundEmployee.name).to.equal('John Doe');
                        done();
                    }
                });
            }
        });
    });
});
